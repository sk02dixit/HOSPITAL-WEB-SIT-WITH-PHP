<?php
session_start();
$emailaddress=$_POST["emailaddress"];
$password=$_POST["password"];
//now connect database.
$con=mysqli_connect("localhost","root","","web");
$query="select password from webnor where emailaddress='$emailaddress'";
$res=mysqli_query($con,$query);

if (mysqli_num_rows($res)>0)
{
    if($row=mysqli_fetch_assoc($res))
    {
        $respassword=$row["password"];
        if($password==$respassword)
        {
            $_SESSION["valid"]=$emailaddress;    
            header("location:index.php");
        }
        else
        {
            echo "<script>alert('Invalid user');   
            window.location.href='login.php';</script>";   //email is correct but password is not correct then msg show Invalid user
        }
    }

}

?>