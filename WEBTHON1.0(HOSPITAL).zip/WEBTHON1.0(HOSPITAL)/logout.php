<?php
session_start();
$session=session_destroy();
session_unset();
if($session==true){
    echo "<script>alert('Logout Successfully');
    window.location.href='index.php';
    </script>";
}
else{
    header("location:index.php");
}
?>