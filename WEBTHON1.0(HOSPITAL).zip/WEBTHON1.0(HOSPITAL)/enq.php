<?php
$name=$_POST["name"];
$email=$_POST["email"];
$mobile=$_POST["mobile"];
$address=$_POST["address"];
$feedback=$_POST["feedback"];
$con=mysqli_connect("localhost","root","","web");
$query="insert into enqinfo (name,email,mobile,address,feedback) values('$name','$email','$mobile','$address','$feedback')";
$res=mysqli_query($con,$query);
echo "<script>alert('YOUR MASSAGE IS SEND BY ADMIN;');
window.location.href='contact.php';</script>";
?>