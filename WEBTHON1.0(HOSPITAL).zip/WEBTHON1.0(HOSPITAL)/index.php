
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REVO</title>
    <!-- font awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css"
        integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="css/bootstrap.css">
    <script src="js/bootstrap.bundle.js"></script>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <style>
        a h5:hover {

            color: red;
            font-weight: 900;
            font-family: cursive;
        }

        .img1 {
            height: 400px;
        }

        h4 {
            color: blue;
        }

        .img2 {
            background-image: url('images/banner-1-img.png');
            height: 400px;
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }

        .img3 {
            background-image: url('images/banner-1-img.png');
            height: 400px;
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }

        button:hover {

            color: rgb(255, 89, 0);
            font-weight: 900;
        }
        nav{
            
        }
       
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row sticky-top">
            <div class="col-sm-12  p-0">
                <nav class="navbar navbar-expand-lg bg-primary">
                    <div class="container-fluid">
                        <img src="images/logo.png" style="height:40ox;" alt="">
                        <button class="navbar-toggler bg-primary" type="button" data-bs-toggle="collapse"
                            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" style="margin-left:10%;" id="navbarSupportedContent">
                            <ul class="navbar-nav me-auto mb-2  mb-lg-0">
                                <li class="nav-item">
                                    <a class="nav-link active text-white " style="font-family:monotype-Corsica;;"
                                        aria-current="page" href="index.php">
                                        <h5>Home.</h5>
                                    </a>
                                </li>
                                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                                <li class="nav-item">
                                    <a class="nav-link active text-white " style="font-family:monotype-Corsica;;"
                                        aria-current="page" href="about.php">
                                        <h5>About Us.</h5>
                                    </a>
                                </li>
                                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                                
                                <li class="nav-item">
                                    <a class="nav-link active text-white " style="font-family:monotype-coreshiva;"
                                        aria-current="page" href="reg.php">
                                        <h5>Registration.</h5>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link active text-white " style="font-family:monotype-coreshiva;"
                                        aria-current="page" href="login.php">
                                        <h5>User Login.</h5>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link active text-white " style="font-family:monotype-coreshiva;"
                                        aria-current="page" href="doclogin.php">
                                        <h5>Doctor Login.</h5>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link active text-white " style="font-family:monotype-coreshiva;"
                                        aria-current="page" href="contact.php">
                                        <h5>Contact us.</h5>
                                    </a>
                                </li>

                            
                            </ul>
                            <form class="d-flex " role="search">
                                <input class="form-control " type="search" placeholder="Search" aria-label="Search">
                                <button class="btn btn-outline-secondary mx-4" type="submit" ><a href="admin.php">admin</a></button>
                                
                            </form>
                           
                        </div>
                    </div>
                </nav>
            </div>
        </div>
        <!--slider start-->
        <div class="row">
            <div class="col-sm-12 p-0 ">
                <div id="carouselExampleCaptions" class="carousel slide">
                    <div class="carousel-indicators">
                        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0"
                            class="active bg-success" aria-current="true" aria-label="Slide 1"></button>
                        <button type="button "class="bg-success" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
                            aria-label="Slide 2"></button>
                        <button type="button "class="bg-success" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
                            aria-label="Slide 3"></button>
                    </div>
                    <div class="carousel-inner text-primary">
                        <div class="carousel-item active">
                            <img src="images/banner-1-img.png" class="d-block w-100 img1" alt="...">
                            <div class="carousel-caption d-none d-md-block text-primary">
                            <h1>Best Doctor Advices</h1>
                                <p>The role of culture in hospitality.</p>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img src="images/banner-two-bg.png" class="d-block w-100 img1" alt="...">
                            <div class="carousel-caption d-none d-md-block text-primary">
                                
                                <h1> The Abril Al Bait.</h1>
                                <p>Some representative placeholder content for the second slide.</p>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img src="images/slider1.jpg" class="d-block w-100 img1" alt="...">
                            <div class="carousel-caption d-none d-md-block text-primary">
                                <h1>All services </h1>
                                <p>Some representative placeholder content for the third slide.</p>
                            </div>
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
                        data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
                        data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>
        </div>
        <!--slider end-->
        <!--main part-->
        <div class="row bg-primary">
            <div class="col-sm-5 text-white text-center">
                <h1 style="font-family:Courier;margin-top: 20%;">Your Most Trusted<br> <span
                        style="font-size: larger;font-weight: 800;font-family: Cambria;">Health Partner</span></h1>
                <h3 style="color:white;">the best match services for you</h3>
                <h6 class="text text-md mt-5" style="color:white;">Lorem, ipsum dolor sit amet consectetur adipisicing
                    elit. Totam, nulla odit esse
                    necessitatibus corporis voluptatem?</h6>
                <button
                    style="border-radius: 25%;border:none;color:blueviolet;background-color:white;padding: 10px;">Read
                    More</button>
                <button
                    style="border-radius: 25%;border:none;color:blueviolet;background-color:rgb(3, 248, 199);padding: 10px;">Sign
                    In</button>
            </div>
            <div class="col-sm-1"></div>
            <div class="col-sm-6">
                <img src="images/header.png" data-aos="zoom-in-down"data-aos-duration="2000" alt="" style="height: 400px;width:100%;">
            </div>
        </div>
        <!--about-->
        <div class="row pt-4">
            <div class="col-sm-6">
                <h2 class="mx-5">About Us</h2>
                <p class="mx-5" style="border-bottom: 5px solid rgb(7, 198, 246);width:40%;"></p><br><br>
                <p class="text p-3 text-center text-justify " style="text-align: justify;font-size:23px;">Cardio Care is an innovative medical practice focusing on, well, you guessed it, cardiovascular health care. This well-known East coast clinic with multiple locations focuses on cutting edge technology and offers patients access to a range of features to manage their health records, schedule testing, access results, and more. </p>
                <button
                    style="border-radius: 25%;border:none;color:blueviolet;background-color:rgb(5, 254, 200);padding: 10px;margin-left: 80%;">Learn
                    More</button>
            </div>
            <div class="col-sm-6 bg-primary">
                <img src="images/about-img.png" data-aos="zoom-in-left"data-aos-duration="2000" style="height: 400px;width:100%;" alt="">
            </div>
        </div>
        <!--background-->
        <div class="row img2 ">
            <div class="col-sm-12  img2 text-center" data-aos="zoom-in" data-aos-duration="2000"style="background: rgba(41, 121, 220, 0.7);">
                <blockquote class="lead" style="font-size: 30px;margin-top:10%;color:white;font-weight: 600;"><i
                        class="fas fa-quote-left"></i> When you are young and healthy, it <br>never occurs to you that
                    in a single<br> second your whole life could change. <i class="fas fa-quote-right"></i></blockquote>
                <small class="text text-sm text-white">-::- Anomia Nano-::-</small>
            </div>
        </div>

        <div class="row  ">
            <div class="col-sm-12 text-center"data-aos="zoom-in" data-aos-duration="2000">
                <h1 style="font-weight: 700;margin-top:10%;font-family: monotype;">The Best Doctor gives the least
                    medicines</h1>
                <h6 style="color:lime;font-family:monotype;font-size:20px;">A perfect way to show your hospital services</h6>
            </div>
        </div>
        <!--four div-->
        <div class="row pt-5">
            <div class="col-sm-3 p-5 text-center" data-aos="zoom-in" data-aos-duration="2000">
                <img src="images/service-icon-1.png" data-aos="zoom-in" data-aos-duration="2000"alt="">
                <h3>Cardio Monitoring</h3>
                <p class="text text-sm " style="text-align: justify;">Cardio Care is an innovative medical practice focusing on, well, you guessed it, cardiovascular health care. This well-known East coast clinic with multiple locations focuses on cutting edge technology and offers patients access to a range of features to manage their health records, schedule testing, access results, and more. </p>
            </div>

            <div class="col-sm-3 p-5 text-center" data-aos="zoom-in" data-aos-duration="2000">
                <img src="images/service-icon-2.png" alt="">
                <h3>Medical Treatment</h3>
                <p class="text text-sm" style="text-align: justify;">Cardio Care is an innovative medical practice focusing on, well, you guessed it, cardiovascular health care. This well-known East coast clinic with multiple locations focuses on cutting edge technology and offers patients access to a range of features to manage their health records, schedule testing, access results, and more.</p>
            </div>

            <div class="col-sm-3 p-5 text-center"data-aos="zoom-in" data-aos-duration="2000">
                <img src="images/service-icon-3.png" alt="">
                <h3>Emergency Help</h3>
                <p class="text text-sm" style="text-align: justify;">Cardio Care is an innovative medical practice focusing on, well, you guessed it, cardiovascular health care. This well-known East coast clinic with multiple locations focuses on cutting edge technology and offers patients access to a range of features to manage their health records, schedule testing, access results, and more.</p>
            </div>

            <div class="col-sm-3 p-5 text-center"data-aos="zoom-in" data-aos-duration="2000">
                <img src="images/service-icon-4.png" alt="">
                <h3>First Aid</h3>
                <p class="text text-sm" style="text-align: justify;">Cardio Care is an innovative medical practice focusing on, well, you guessed it, cardiovascular health care. This well-known East coast clinic with multiple locations focuses on cutting edge technology and offers patients access to a range of features to manage their health records, schedule testing, access results, and more.</p>
            </div>

        </div>

        <!--back end-->
              
        <div class="row img3">
            
            <div class="col-sm-12 ">
                <div class="row" style="background: rgba(42, 99, 200, 0.7);">
                    <div class="col-sm-6 p-4"data-aos="zoom-in-left" data-aos-duration="2000">
                        <img src="images/banner-2-img.png" style="height:300px;width:100%;margin-top:10%;" alt="">
                    </div>
                    <div class="col-sm-6"data-aos="zoom-in" data-aos-duration="2000">
                        <h2 class="lead text-white" style="margin-top:25%;font-weight:400;">When you are young and
                            healthy, it never occurs to<br> you that in a single second your whole life <br>could
                            change.</h2>
                        <div class="btn-group">
                            <button style="border:none;background-color:white;padding:10px;border-radius:20%">Read More</button>
                            <button style="border:none;background-color:#2db5ec;padding:10px;border-radius:20%;margin-left: 10px;">Sign in</button>
                        </div>

                    </div>
             </div>
            </div>
           

          <!--3 card button-->

     <div class="row">
                <div class="col-sm-4 p-4">
                    <div class="card w-100" style="width: 18rem;border:30%;">
                        <i class = "fas fa-phone fa-2x text-center mt-4" style="background-color: aqua;clip-path: circle(2);"></i>
                        <img src="images/post-1.jpg" data-aos="zoom-in" data-aos-duration="2000"class="card-img-top" alt="...">
                        <div class="card-body">
                            <h3>Regular Case</h3>
                            <p class = "text text-sm">Cardio Care is an innovative medical practice focusing on, well, you guessed it, cardiovascular health care. This well-known East coast clinic with multiple locations focuses on cutting .</p>
                          <a href="#" class="btn btn-primary">Lear more</a>
                        </div>
                      </div>
                </div>
                  
                <div class="col-sm-4 p-4">
                    <div class="card w-100 h-100" style="width: 18rem;border:30%;">
                        <i class = "fas fa-calendar-alt fa-2x text-center mt-4" style="background-color: aqua;clip-path: circle(2);"></i>
                        <img src="images/post-2.jpg" data-aos="zoom-in" data-aos-duration="2000"class="card-img-top" alt="...">
                        <div class="card-body">
                            <h3>Serious Case</h3>
                            <p class = "text text-sm">Cardio Care is an innovative medical practice focusing on, well, you guessed it, cardiovascular health care. This well-known East coast clinic with multiple locations focuses on cutting .</p>
                          <a href="#" class="btn btn-primary">Lear more</a>
                        </div>
                      </div>
                </div>

                <div class="col-sm-4 p-4">
                    <div class="card w-100 h-100" style="width: 18rem;border:30%;">
                        <i class = "fas fa-comments fa-2x text-center mt-4" style="background-color: aqua;clip-path: circle(2);"></i>
                        <img src="images/post-3.jpg"data-aos="zoom-in" data-aos-duration="2000" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h3>Emergency Case</h3>
                        <p class = "text text-sm">Cardio Care is an innovative medical practice focusing on, well, you guessed it, cardiovascular health care. This well-known East coast clinic with multiple locations focuses on cutting .</p>
                          <a href="#" class="btn btn-primary">Lear more</a>
                        </div>
                      </div>
                </div>
                
               
            </div>
      
            <!-- main end-->
        <div class="row">
            <div class="col-sm-12">
              <h1 class="mx-5">Our Doctors <hr style="background-color:blue;width:20%;height:5px;"></h1>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-3 ">
            <div class="card h-100" style="width: 18rem;box-shadow: 15px 10px 15px blue;margin: left 50px;">
             <img src="images/doc-1.png" class="card-img-top" alt="...">
                  <div class="card-body">
                  <p class="card-text"><h4>Our Doctor Physicians</h4>
                    Licensed in their respective states, Covered by malpractice insurance for OurDoctor
                     consultations, Located in the United States.</p>
                  </div>
           </div>
            </div>

            <div class="col-sm-3 ">
            <div class="card h-100" style="width: 18rem;box-shadow: 15px 10px 15px blue;">
             <img src="images/doc-2.png" class="card-img-top" alt="...">
                  <div class="card-body">
                  <p class="card-text"><h4>Our Doctor Physicians</h4>
                    Licensed in their respective states, Covered by malpractice insurance for OurDoctor
                     consultations, Located in the United States.</p>
                  </div>
           </div>
            </div>

            <div class="col-sm-3 ">
            <div class="card h-100" style="width: 18rem;box-shadow: 15px 10px 15px blue;">
             <img src="images/doc-3.png" class="card-img-top" alt="...">
                  <div class="card-body">
                  <p class="card-text"><h4>Our Doctor Physicians</h4>
                    Licensed in their respective states, Covered by malpractice insurance for OurDoctor
                     consultations, Located in the United States.</p>
                  </div>
           </div>
            </div>

            <div class="col-sm-3 ">
            <div class="card h-100" style="width: 18rem;box-shadow: 15px 10px 15px blue;">
             <img src="images/doc-4.png" class="card-img-top" alt="...">
                  <div class="card-body">
                  <p class="card-text"><h4>Our Doctor Physicians</h4>
                    Licensed in their respective states, Covered by malpractice insurance for OurDoctor
                     consultations, Located in the United States.</p>
                  </div>
           </div>
            </div>
        </div>
           <!--footer hai-->

           <div class="row bg-primary pt-4" style="height:350px;">
            
            <div class="col-sm-11">
                <div class="row">
                    <div class="col-sm-3">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2384.6268289831164!2d-6.214682984112116!3d53.29621947996855!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x486709e0c9c80f8f%3A0x92f408d10f2277c2!2sREVO!5e0!3m2!1sen!2snp!4v1636264848776!5m2!1sen!2snp" width="100%" height="380" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                    </div>
                    <div class="col-sm-3 mt-4">
                        <h5 class="text-white mx-4">USEFUL LINKS</h5><hr class="mx-4" style="border:2px solid white;"/>
                        <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Home</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                        <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  About Us</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                        <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Portpolio</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                        <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Career</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                        <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Contact</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                    </div>
                    <div class="col-sm-3 mt-4">
                        <h5 class="text-white mx-4">Contact Us</h5><hr class="mx-4 " style="border:2px solid white;"/>
                        <p class="text-white mx-4">REVO <br/>
                            
                            Call us @ + 91 8601670688<br/>
                            Email Revo@.in<br/>
                 
                        </p>
                        <div class="row">
                            <div class="col-sm-1"></div>
                            <div class="col-sm-2 " >
                            <i class="fa-brands fa-instagram" style="color:white;padding:1px;margin-top:12px;font-size:45px;"></i>
                            </div>
                            <div class="col-sm-2 ">
                            <i class="fa-brands fa-facebook" style="color:white;padding:1px;margin-top:12px;font-size:40px;"></i>
                            </div>
                            <div class="col-sm-2 ">
                            <i class="fa-brands fa-youtube" style="color:white;margin-top:14px;font-size:40px;"></i>
                            </div>
                            <div class="col-sm-2 ">
                            <i class="fa-brands fa-twitter" style="color:white;padding:1px;margin-top:12px;font-size:40px;"></i>
                            </div>
                            <div class="col-sm-2 ">
                            <i class="fa-brands fa-linkedin" style="color:white;padding:1px;margin-top:12px;font-size:45px;"></i>
                            </div>
                            <div class="col-sm-1"></div>
                        </div>
                    </div>
                    <div class="col-sm-3 mt-4">
                    <h5 class=" mx-4" style="color:orange;">DOWNLOADS</h5><hr class="mx-4" style="border:2px solid white;"/>
                        <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> COMPANY PROFILE</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                        <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;font-size:14px;"> VOLUME I (EDITION NOV-2017)</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                        <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;font-size:14px;"> VOLUME II (EDITION JUNE-2018)</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                        <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;font-size:14px;"> VOLUME III (EDITION JUNE-2020)</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                        
                    </div>
                </div>
            </div>
            <div class="col-sm-1"></div>
        </div>
        <div class="row" style="height:100px;background-color:black;">
            <div class="col-sm-12">
                <p class="text-center mt-4 text-white">© Copyright ©® All Rights Reserved <br/>
                                       Designed by <span style="color:red;"> @SUDHIR DIXIT</span><p>
            </div>
        </div>

           <!--end footter-->

        </div>
</body>
<script>
  AOS.init();
</script>

</html>