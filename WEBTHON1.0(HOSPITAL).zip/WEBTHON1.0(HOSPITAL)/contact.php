<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact us</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css"
        integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="css/bootstrap.css">
    <script src="js/bootstrap.bundle.js"></script>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <style>
        .img1 {
            background: url('images/banner-1-img.png');
            height: 380px;
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
    </style>
    <style>
        a h5:hover {

            color: red;
            font-weight: 900;
            font-family: cursive;
        }

        

        h4 {
            color: white;
        }

        .img2 {
            background-image: url('images/banner-1-img.png');
            height: 400px;
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }

        .img3 {
            background-image: url('images/post-2.jpg');
            height: 600px;;
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            
        }

        button:hover {

            color: rgb(255, 89, 0);
            font-weight: 900;
        }

        form{
            color:white;
            padding:10px;
        }
    </style>
    <!-- <script>
        function validate() {
         
            var email = document.myform.email.value;
            var mobile= document.myform.mobile.value;
            

            var expemail = "^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$"; 

          
             if (email==null || email=="") {
                alert("please enter email address");
                return false;
            }
           
            else if (!expemail.test(email)) {
                alert("Enter valid email address;");
                return false;
            }

           

            else if (mobile == null || mobile == "") {
                alert("please enter number");
                return false;
            }
            else if (mobile.length <= 10  ) {
                alert("Number must be atleast 10 chars");
                return false;
           
            }
        }
              
            
    </script> -->
    </head>

<body >
    <!--nav bar-->
    <div class="container-fluid">
    <div class="row sticky-top">
            <div class="col-sm-12  p-0">
                <nav class="navbar navbar-expand-lg bg-primary">
                    <div class="container-fluid">
                        <img src="images/logo.png" style="height:40ox;" alt="">
                        <button class="navbar-toggler bg-primary" type="button" data-bs-toggle="collapse"
                            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" style="margin-left:10%;"id="navbarSupportedContent">
                            <ul class="navbar-nav me-auto mb-2  mb-lg-0">
                                <li class="nav-item">
                                    <a class="nav-link active text-white " style="font-family:monotype-Corsica;"
                                        aria-current="page" href="index.php">
                                        <h5>Home.</h5>
                                    </a>
                                </li>
                                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                                <li class="nav-item">
                                    <a class="nav-link active text-white " style="font-family:monotype-Corsica;;"
                                        aria-current="page" href="about.php">
                                        <h5>About Us.</h5>
                                    </a>
                                </li>
                                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                               
                                <li class="nav-item">
                                    <a class="nav-link active text-white " style="font-family:monotype-coreshiva;"
                                        aria-current="page" href="reg.php">
                                        <h5>Registration.</h5>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link active text-white " style="font-family:monotype-coreshiva;"
                                        aria-current="page" href="login.php">
                                        <h5>Login.</h5>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link active text-white " style="font-family:monotype-coreshiva;"
                                        aria-current="page" href="contact.php">
                                        <h5>Contact us.</h5>
                                    </a>
                                </li>


                            </ul>
                            <form class="d-flex mx-5" role="search">
                                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                                <button class="btn btn-outline-success" type="submit">Search</button>
                            </form>
                        </div>
                    </div>
                </nav>
            </div>
 </div>
    
    <!--end nav-->
       <div class="row img1" data-aos="zoom-in" data-aos-duration="2000">
             <div class="col-sm-12 img1" style="background: rgba(41, 121, 220, 0.7);">
              <h1 style="text-align:center;margin-top:15%;font-size:100px;color:white;">Contact Us</h1>
             </div>
       </div>
             <!--contect-->
                 
            
        <div class="row mt-5 " style="background-color:transparent;">
            <div class="col-sm-12">
                <h2 class="text-center" style="background-color:#f7f7f7;">  <span style="color:orangered;">Contact Us</span></h2>
            </div>
        </div>
        <div class="row" style="background-color:#f7f7f7;">
            <div class="col-sm-5"></div>
            <div class="col-sm-2 mx-5 " style="border:2px solid orangered;border-radius:50%;width:130px;"></div>
            <div class="col-sm-6"></div>
        </div>
        <div class="row">
            <div class="col-sm-12 mt-4">
                <h4 class="text-center" style="color:black;font-family:gabrilla;">Get in Touch, We Cherish all Interactions<h4>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-sm-1"></div>
            <div class="col-sm-10">
                <div class="row">
                    <div class="col-sm-4" style="border-right:2px solid grey;">
                    <i class="fa-solid fa-location-dot" style="color:orangered;font-size:30px;margin-left:47%;"></i><br/>
                    <h3 class="text-center mt-3" style="color:grey;">Address</h3>
                    <p class="text-center"><strong>Head Office : </strong>USA</p>
                    <p class="text-center">Location: Cleveland, Ohio, United States</p>
                    <p class="text-center">  Baltimore, United States</p>
                    </div>
                    <div class="col-sm-4" style="border-right:2px solid grey;">
                    <i class="fa-solid fa-phone" style="color:orangered;font-size:30px;margin-left:47%;"></i><br/>
                    <h3 class="text-center mt-3" style="color:grey;">Contact Number</h3>
                    <p class="text-center mt-4" ><a href="#" style="text-decoration:none;color:black;">+91 8601670688</a></p>
                    <p class="text-center hov" style="margin-top:-10px;"><a href="#" style="text-decoration:none;color:black;">+91 8601670688</a></p>
                   
            
                    
                    </div>
                    <div class="col-sm-4" >
                    <i class="fa-solid fa-envelope" style="color:orangered;font-size:30px;margin-left:45%;"></i><br/>
                    <h3 class="text-center mt-3" style="color:grey;">Email</h3>
                    <p class="text-center mt-4"><a href="#" style="text-decoration:none;color:black;">REVO@GAMIL.COMn</a></p>
                    <p class="text-center" style="margin-top:-10px;"><a href="#" style="text-decoration:none;color:black;">enquirey@REVO.in</a></p>
                   
                    </div>
                </div>
            </div>
            <div class="col-sm-1"></div>
        </div>


             <!--end-->
       <div class="row img3">
        <div class="col-sm-6  p-0">
       <img src="images/contact1.gif"style="background-color:#0076b8;height:600px;width:100%;" alt="">
        </div>
        <div class="col-sm-6 img3"style="background: rgba(41, 121, 220, 0.7);" >
          <center>
          <form action="enq.php"method="post" onsubmit="return validate()" name="myform">
            Enter Your Name:  <input type="text" name="name"placeholder="ENTER YOUR NAME" class="form-control"required><br>
            Enter Email Address: <input type="email" name="email" placeholder="ENTER YOUR EMAIL;" class="form-control" required="true"><br>
            Enter YOUR MOBIL NUMBER: <input type="number" name="mobile" maxlength="10" minlength="10"placeholder="ENTER YOUR CONTACT NO." required="true" class="form-control"><br>
            Enter your Address: <textarea name="address"  cols="30" rows="3" placeholder="Enter Your Address"required="true" class="form-control"></textarea><br>
            Enter your feedback:
            <textarea name="feedback"required="true" cols="30" rows="3" placeholder="Enter your feedback" class="form-control"></textarea>
            <input type="submit" required="true"value="Submit" name="submit" class="form-control w-50 bg-success text-white mt-5">
           </form>
          </center>
        </div>
       </div>
       <!--last-->
         
       
    <!--footter-->
    <div class="row bg-primary " style="height:350px;">
            
            <div class="col-sm-11">
                <div class="row">
                    <div class="col-sm-3">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2384.6268289831164!2d-6.214682984112116!3d53.29621947996855!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x486709e0c9c80f8f%3A0x92f408d10f2277c2!2sREVO!5e0!3m2!1sen!2snp!4v1636264848776!5m2!1sen!2snp" width="100%" height="350" style="border:7px dotted red;" allowfullscreen="" loading="lazy"></iframe>
                    </div>
                    <div class="col-sm-3 mt-4">
                        <h5 class="text-white mx-4">USEFUL LINKS</h5><hr class="mx-4" style="border:2px solid white;"/>
                        <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Home</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                        <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  About Us</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                        <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Portpolio</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                        <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Career</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                        <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> >  Contact</a></p><hr class="mx-4" style="border:.5px solid grey;width:80%;margin-top:-10px;"/>
                    </div>
                    <div class="col-sm-3 mt-4">
                        <h5 class="text-white mx-4">Contact Us</h5><hr class="mx-4 " style="border:2px solid white;"/>
                        <p class="text-white mx-4">REVO <br/>
                            
                            Call us @ + 91 8601670688<br/>
                            Email Revo@.in<br/>
                 
                        </p>
                        <div class="row">
                            <div class="col-sm-1"></div>
                            <div class="col-sm-2 " >
                            <i class="fa-brands fa-instagram" style="color:white;padding:1px;margin-top:12px;font-size:45px;"></i>
                            </div>
                            <div class="col-sm-2 ">
                            <i class="fa-brands fa-facebook" style="color:white;padding:1px;margin-top:12px;font-size:40px;"></i>
                            </div>
                            <div class="col-sm-2 ">
                            <i class="fa-brands fa-youtube" style="color:white;margin-top:14px;font-size:40px;"></i>
                            </div>
                            <div class="col-sm-2 ">
                            <i class="fa-brands fa-twitter" style="color:white;padding:1px;margin-top:12px;font-size:40px;"></i>
                            </div>
                            <div class="col-sm-2 ">
                            <i class="fa-brands fa-linkedin" style="color:white;padding:1px;margin-top:12px;font-size:45px;"></i>
                            </div>
                            <div class="col-sm-1"></div>
                        </div>
                    </div>
                    <div class="col-sm-3 mt-4 text-white">
                    <h5 class=" mx-4" style="color:orange;">DOWNLOADS</h5><hr class="mx-4" style="border:2px solid white;"/>
                        <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;"> COMPANY PROFILE</a></p><hr class="mx-4" style="border:.5px solid white;width:80%;margin-top:-10px;"/>
                        <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;font-size:14px;"> VOLUME I (EDITION NOV-2017)</a></p><hr class="mx-4" style="border:.5px solid white;width:80%;margin-top:-10px;"/>
                        <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;font-size:14px;"> VOLUME II (EDITION JUNE-2018)</a></p><hr class="mx-4" style="border:.5px solid white;width:80%;margin-top:-10px;"/>
                        <p class="mx-4"><a href="#" class="text-white " style="text-decoration:none;font-size:14px;"> VOLUME III (EDITION JUNE-2020)</a></p><hr class="mx-4" style="border:.5px solid white;width:80%;margin-top:-10px;"/>
                        
                    </div>
                </div>
            </div>
            <div class="col-sm-1"></div>
        </div>
        <div class="row" style="height:100px;background-color:black;">
            <div class="col-sm-12">
                <p class="text-center mt-4 text-white">© Copyright ©® All Rights Reserved <br/>
                                       Designed by <span style="color:red;"> @SUDHIR DIXIT</span><p>
            </div>
        </div>
    <!-- endfootter-->
    </div>
</body>
<script>
  AOS.init();
</script>
</html>