<?php
if(isset($_POST["submit"])){
$name=$_POST["name"];
$emailaddress=$_POST["emailaddress"];
$password=$_POST["password"];
$batch=$_POST["batch"];
$contactno=$_POST["contactno"];
$gender=$_POST["gender"];
$con=mysqli_connect("localhost","root","","web");
$query="insert into docinfo(name,emailaddress,password,batch,contactno,gender) values ('$name','$emailaddress','$password','$batch','$contactno','$gender')";
mysqli_query($con,$query);
echo "<script>alert('Registration is Done');
window.location.href='doclogin.php';</script>";
}else{
    header("location:docreg.php");
}
?>