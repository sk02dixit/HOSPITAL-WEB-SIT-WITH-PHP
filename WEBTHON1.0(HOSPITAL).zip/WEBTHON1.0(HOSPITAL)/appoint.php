<?php
if(isset($_POST["submit"])){
$name=$_POST["name"];
$email=$_POST["email"];
$mobile=$_POST["mobile"];
$selDep=$_POST["selDep"];
$date=$_POST["date"];
$selDoc=$_POST["selDoc"];
$gender=$_POST["gender"];
$address=$_POST["address"];
$con=mysqli_connect("localhost","root","","web");
$query="insert into app(name,email,mobile,selDep,date,selDoc,gender,address) values ('$name','$email','$mobile','$selDep','$date','$selDoc','$gender','$address')";
mysqli_query($con,$query);
echo "<script>alert('Appointment  is successful☺😚   ');
window.location.href='appointments.php';</script>";
}else{
    header("location:reg.php");
}

?>