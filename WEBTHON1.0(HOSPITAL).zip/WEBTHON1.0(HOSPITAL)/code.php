<?php
if(isset($_POST["submit"])){
$name=$_POST["name"];
$emailaddress=$_POST["emailaddress"];
$password=$_POST["password"];
$age=$_POST["age"];
$contactno=$_POST["contactno"];
$gender=$_POST["gender"];
$con=mysqli_connect("localhost","root","","web");
$query="insert into webnor(name,emailaddress,password,age,contactno,gender) values ('$name','$emailaddress','$password','$age','$contactno','$gender')";
mysqli_query($con,$query);
echo "<script>alert('Registration is Done');
window.location.href='index.php';</script>";
}else{
    header("location:reg.php");
}
?>